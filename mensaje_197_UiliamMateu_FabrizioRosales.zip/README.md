# Problema_197
[Link](https://www.aceptaelreto.com/pub/problems/v001/97/st/statements/Spanish/index.html)

